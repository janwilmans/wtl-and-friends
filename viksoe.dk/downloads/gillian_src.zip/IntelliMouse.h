#if !defined(AFX_INTELLIMOUSE_H__20040813_7AA6_5676_CAA3_0080AD509054__INCLUDED_)
#define AFX_INTELLIMOUSE_H__20040813_7AA6_5676_CAA3_0080AD509054__INCLUDED_

#pragma once

/////////////////////////////////////////////////////////////////////////////
// IntelliMouse.h - Window IntelliMouse support
//
// Written by Bjarke Viksoe (bjarke@viksoe.dk)
// Copyright (c) 2004-2007 Bjarke Viksoe.
//
// This code may be used in compiled form in any way you desire. This
// source file may be redistributed by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to you or your
// computer whatsoever. It's free, so don't hassle me about it.
//
// Beware of bugs.
//


#if !((_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400)) && !defined(_WIN32_WCE)
  #include <zmouse.h>
#endif //!((_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400)) && !defined(_WIN32_WCE)


#ifndef IDI_PANCENTER
   #error "Missing IntelliMouse ressources! Please add icons and cursors for this class."
   // The following resources are needed by this class:
   //     IDI_PANCENTER
   //     IDC_PAN_S
   //     IDC_PAN_N
   //     IDC_PAN_E
   //     IDC_PAN_W
   //     IDC_PAN_X
   //     IDC_PAN_NW
   //     IDC_PAN_NE
   //     IDC_PAN_SE
   //     IDC_PAN_SW
#endif

#ifndef TIMERID_INTELLIMOUSE
   #define TIMERID_INTELLIMOUSE 543
   #define TIMERID_DRAGDETECT   544
#endif

// Direction flags
#define PAN_UPDOWN       1
#define PAN_LEFTRIGHT    2
#define PAN_BOTH         3

// IntelliMouse styles
#define ITS_SCROLLCHILDREN  0x00000001          // Container needs child-window scrolling
#define ITS_SETSCROLLINFO   0x00000002          // Container is using GetScrollInfo() rather than WM_xSCROLL params



typedef CWinTraits<WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, WS_EX_TOPMOST | WS_EX_TRANSPARENT> CIntelliWindowTraits;

template< class T >
class CIntelliMouseImpl : public CWindowImpl<T, CWindow, CIntelliWindowTraits>
{
public:
   enum { CIRCLE_SIZE = 34 };

   int m_iRate;                       // Repaint refresh rate (ms)
   bool m_bCaptured;                  // Has window mouse capture?
   bool m_bAutoScrollMode;            // In autoscroll mode
   POINT m_ptCenter;                  // Center of panning
   DWORD m_dwStyle;                   // Style flags
   int m_iFactor;                     // Scale factor
   int m_iDirection;                  // Pan directions allowed
   CRgn m_Region;                     // Region/path for center area
#if !((_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400)) && !defined(_WIN32_WCE)
   UINT m_uMsgMouseWheel;             // Mouse-wheel support for Win9x
#endif
   CContainedWindow m_wndParent;      // Parent window
   CWindow m_wndScroll;
   HICON m_hIconCenter;               // Pan icon (center circle)
   HCURSOR m_hCursorN;                // Pan cursor
   HCURSOR m_hCursorNW;               // Pan cursor
   HCURSOR m_hCursorNE;               // Pan cursor
   HCURSOR m_hCursorS;                // Pan cursor
   HCURSOR m_hCursorSW;               // Pan cursor
   HCURSOR m_hCursorSE;               // Pan cursor
   HCURSOR m_hCursorE;                // Pan cursor
   HCURSOR m_hCursorW;                // Pan cursor
   HCURSOR m_hCursorX;                // Pan cursor

   CIntelliMouseImpl() : 
      m_wndParent(this, 1), 
      m_bCaptured(false), 
      m_bAutoScrollMode(false), 
      //m_uMsgMouseWheel(0U), 
      m_iFactor(1),
      m_dwStyle(0UL),
      m_iDirection(PAN_BOTH)
   {
   }
   ~CIntelliMouseImpl()
   {
      Uninstall();
   }

   // Operations

   BOOL Install(HWND hWnd, int iDirectionLimit = PAN_BOTH, int iRefreshRate = 100, int iScaleFactor = 2)
   {
      ATLASSERT(!m_wndParent.IsWindow()); // Don't install twice!
      SetRefreshRate(iRefreshRate);
      SetScaleFactor(iScaleFactor);
      SetDirectionLimit(iDirectionLimit);
      if( !m_wndParent.SubclassWindow(hWnd) ) return FALSE;
      m_wndScroll = m_wndParent;
#if !((_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400))
      m_uMsgMouseWheel = ::RegisterWindowMessage(MSH_MOUSEWHEEL);
#endif
      T* pT = static_cast<T*>(this); pT;
      pT->OnInstall(hWnd);
      return TRUE;
   }
   void Uninstall()
   {
      if( m_wndParent.IsWindow() ) m_wndParent.UnsubclassWindow();
      if( m_bCaptured ) ReleaseCapture();
      if( IsWindow() ) DestroyWindow();
   }

   void SetIntelliStyle(DWORD dwStyle)
   {
      m_dwStyle = dwStyle;
   }
   void SetDirectionLimit(int iDirection)
   {
      m_iDirection = iDirection;
   }
   int GetDirectionLimit() const
   {
      return m_iDirection;
   }
   void SetRefreshRate(int iRate)
   {
      m_iRate = iRate;
   }
   void SetScaleFactor(int iFactor)
   {
      ATLASSERT(iFactor>0);
      m_iFactor = iFactor;
   }
   int GetScaleFactor() const
   {
      return m_iFactor;
   }
   POINT GetCenter() const
   {
      return m_ptCenter;
   }
   CWindow GetScrollWindow() const
   {
      ATLASSERT(::IsWindow(m_wndScroll));
      return m_wndScroll;
   }
   void SetScrollWindow(HWND hWnd)
   {
      ATLASSERT(::IsWindow(hWnd));
      m_wndScroll = hWnd;
   }

   // Message map and handlers

   BEGIN_MSG_MAP(CIntelliMouseImpl)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
      MESSAGE_HANDLER(WM_TIMER, OnTimer)
      MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
      MESSAGE_HANDLER(WM_PAINT, OnPaint)
      MESSAGE_HANDLER(WM_CAPTURECHANGED, OnCaptureChanged)
      MESSAGE_HANDLER(WM_MBUTTONUP, OnMButtonUp)
      MESSAGE_HANDLER(WM_LBUTTONDOWN, OnMButtonUp)
      MESSAGE_HANDLER(WM_RBUTTONDOWN, OnMButtonUp)
#if !((_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400)) && !defined(_WIN32_WCE)
      MESSAGE_HANDLER(m_uMsgMouseWheel, OnMouseWheel)
#endif //!((_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400)) && !defined(_WIN32_WCE)
      MESSAGE_HANDLER(WM_MOUSEMOVE, OnMouseMove)
   ALT_MSG_MAP(1)
      MESSAGE_HANDLER(WM_MBUTTONDOWN, OnMButtonDown)
      MESSAGE_HANDLER(WM_LBUTTONDOWN, OnXButtonDown)
      MESSAGE_HANDLER(WM_RBUTTONDOWN, OnXButtonDown)
      MESSAGE_HANDLER(WM_MBUTTONUP, OnMButtonUp)
      MESSAGE_HANDLER(WM_MOUSEWHEEL, OnMouseWheel)
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
#if (_ATL_VER >= 0x0700)
      HINSTANCE hInst = ATL::_AtlBaseModule.GetResourceInstance();
#else
      HINSTANCE hInst = _Module.GetResourceInstance();
#endif
      m_hIconCenter = ::LoadIcon(hInst, MAKEINTRESOURCE(IDI_PANCENTER));
      m_hCursorN    = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_N));
      m_hCursorNW   = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_NW));
      m_hCursorNE   = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_NE));
      m_hCursorS    = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_S));
      m_hCursorSW   = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_SW));
      m_hCursorSE   = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_SE));
      m_hCursorE    = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_E));
      m_hCursorW    = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_W));
      m_hCursorX    = ::LoadCursor(hInst, MAKEINTRESOURCE(IDC_PAN_X));
      ATLASSERT(m_hIconCenter!=NULL);
      return 0;
   }
   LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      ::DestroyIcon(m_hIconCenter);
      ::DestroyIcon(m_hCursorN);
      ::DestroyIcon(m_hCursorNW);
      ::DestroyIcon(m_hCursorNE);
      ::DestroyIcon(m_hCursorS);
      ::DestroyIcon(m_hCursorSW);
      ::DestroyIcon(m_hCursorSE);
      ::DestroyIcon(m_hCursorE);
      ::DestroyIcon(m_hCursorW);
      ::DestroyIcon(m_hCursorX);
      return 0;
   }
   LRESULT OnCaptureChanged(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
   {
      if( m_bCaptured ) {
         KillTimer(TIMERID_INTELLIMOUSE);
         KillTimer(TIMERID_DRAGDETECT);
         PostMessage(WM_CLOSE);
         m_wndParent.SetFocus();
         m_bCaptured = false;
         m_bAutoScrollMode = false;
         return 0;
      }
      bHandled = FALSE;
      return 0;
   }
   LRESULT OnMouseMove(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
   {
      POINT pt = { GET_X_LPARAM(lParam) , GET_Y_LPARAM(lParam) };
      ClientToScreen(&pt);
      _SetPanCursor(pt);
      return 0;
   }
   LRESULT OnTimer(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled)
   {
      bHandled = FALSE;
      if( wParam == TIMERID_INTELLIMOUSE ) {
         // Repaint icon
         Invalidate();
         // Get current mouse position and scroll parent
         T* pT = static_cast<T*>(this); pT;
         RECT rcWin = { 0 };
         GetWindowRect(&rcWin);
         POINT pt = { 0 };
         ::GetCursorPos(&pt);
         pT->OnMove(pt);
         if( (m_dwStyle & ITS_SCROLLCHILDREN) != 0 ) {
            ::MapWindowPoints(NULL, GetParent(), (LPPOINT) &rcWin, 2);
            SetWindowPos(HWND_TOP, rcWin.left, rcWin.top, rcWin.right - rcWin.left, rcWin.bottom - rcWin.top, 0);
         }
         _SetPanCursor(pt);
      }
      else if( wParam == TIMERID_DRAGDETECT ) {
         // Timer triggers after mouse have been down for a predetermined
         // period. We recognize this as a drag.
         m_bAutoScrollMode = false;
         KillTimer(TIMERID_DRAGDETECT);
      }
      return 0;
   }
   LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      return 1;
   }
   LRESULT OnPaint(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      T* pT = static_cast<T*>(this); pT;
      if( wParam != NULL ) {
         pT->DoPaint( (HDC) wParam );
      }
      else {
         CPaintDC dc = m_hWnd;
         pT->DoPaint(dc.m_hDC);
      }
      return 0;
   }

   // Parent messages

   LRESULT OnXButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
   {
      if( m_bAutoScrollMode ) ReleaseCapture();
      bHandled = FALSE;
      return 0;
   }
   LRESULT OnMButtonDown(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
   {
      ATLASSERT(!IsWindow());
      ATLASSERT(m_wndParent.IsWindow());
      // If still in autoscroll mode, we'll have to leave it
      if( m_bAutoScrollMode ) {
         ReleaseCapture();
         return 0;
      }
      // Set default origin
      POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
      m_ptCenter = pt;
      m_wndParent.ClientToScreen(&m_ptCenter);
      // Start panning...
      RECT rcWindow = { pt.x, pt.y, pt.x + CIRCLE_SIZE, pt.y + CIRCLE_SIZE };
      Create(m_wndParent, rcWindow);
      ATLASSERT(::IsWindow(m_hWnd));
      if( !IsWindow() ) return 0;
      // Create region for center
      if( m_Region.IsNull() ) m_Region.CreateEllipticRgn(0, 0, CIRCLE_SIZE, CIRCLE_SIZE);
      CRgn rgn;
      rgn.CreateRectRgn(0, 0, 0 ,0);
      rgn.CopyRgn(m_Region);
      SetWindowRgn(rgn.Detach(), FALSE);
      SetWindowPos(HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
      // Capture the mouse
      SetCapture();
      m_bCaptured = true;
      // Detect if we're in autoscroll mode
      // NOTE: We would have used DragDetect() here, but it's only working
      //       with the left mousebutton
      m_bAutoScrollMode = true;
      SetTimer(TIMERID_DRAGDETECT, 300L);    // 300 ms timeout
      // Start the refresh timer
      SetTimer(TIMERID_INTELLIMOUSE, m_iRate);
      return 0;
   }
   LRESULT OnMButtonUp(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
   {      
      if( m_bCaptured && !m_bAutoScrollMode ) ReleaseCapture();
      bHandled = FALSE;
      return 0;
   }
   LRESULT OnMouseWheel(UINT uMsg, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {      
      T* pT = static_cast<T*>(this); pT;
      if( m_bCaptured ) ::ReleaseCapture();
#if (_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400) || defined(_WIN32_WCE)
      uMsg;
      int zDelta = (int) (short) HIWORD(wParam);
#else
      int zDelta = (uMsg == WM_MOUSEWHEEL) ? (int) (short) HIWORD(wParam) : (int) wParam;
#endif //!((_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400) || defined(_WIN32_WCE))
      POINT pt = m_ptCenter;
      DWORD dwStyle = pT->OnGetScrollFlags();
      if( (dwStyle & WS_VSCROLL) != 0 ) {
         pt.y -= zDelta;
      }
      else if( (dwStyle & WS_HSCROLL) != 0 ) {
         pt.x -= zDelta;
      }
      // Scroll view in compliance to IntelliMouse specs
      if( ( ((WORD) ::GetKeyState(VK_CONTROL)) & 0x8000) != 0 ) {
         pT->OnZoom(pt);
      }
      else if( ( ((WORD) ::GetKeyState(VK_SHIFT)) & 0x8000) != 0 ) {
         pT->OnDataZoom(pt);
      }
      else {
         pT->OnScroll(pt);
      }
      return 0;
   }

   // Implementation

   void _SetPanCursor(POINT pt)
   {
      T* pT = static_cast<T*>(this); pT;
      SIZE sz = { 0 };
      int iDirection = pT->OnCalculate(pt, sz);
      switch( iDirection ) {
      case HTTOP:
         ::SetCursor(m_hCursorN);
         break;
      case HTTOPLEFT:
         ::SetCursor(m_hCursorNW);
         break;
      case HTTOPRIGHT:
         ::SetCursor(m_hCursorNE);
         break;
      case HTBOTTOM:
         ::SetCursor(m_hCursorS);
         break;
      case HTBOTTOMLEFT:
         ::SetCursor(m_hCursorSW);
         break;
      case HTBOTTOMRIGHT:
         ::SetCursor(m_hCursorSE);
         break;
      case HTLEFT:
         ::SetCursor(m_hCursorW);
         break;
      case HTRIGHT:
         ::SetCursor(m_hCursorE);
         break;
      default:
         ::SetCursor(m_hCursorX);
         break;
      }
   }

   // Overridables

   void DoPaint(CDCHandle dc)
   {
      CBrush brushBlack;
      brushBlack.CreateSolidBrush(RGB(40,40,40));
      CBrush brushWhite;
      brushWhite.CreateSolidBrush(RGB(255,255,255));
      dc.FillRgn(m_Region, brushWhite);
      dc.FrameRgn(m_Region, brushBlack, 1, 1);
      dc.DrawIcon(1, 1, m_hIconCenter);
   }
};

class CIntelliMouse : public CIntelliMouseImpl<CIntelliMouse>
{
public:
   void OnInstall(HWND /*hWnd*/)
   {
   }
   int OnCalculate(POINT pt, SIZE& speed)
   {     
      SCROLLINFO horz = { sizeof(SCROLLINFO), SIF_POS | SIF_RANGE };
      SCROLLINFO vert = { sizeof(SCROLLINFO), SIF_POS | SIF_RANGE };
      GetScrollWindow().GetScrollInfo(SB_HORZ, &horz);
      GetScrollWindow().GetScrollInfo(SB_VERT, &vert);

      // Determine delta-distance
      speed.cx = (GetCenter().x - pt.x) / GetScaleFactor();
      speed.cy = (GetCenter().y - pt.y)  / GetScaleFactor();

      // Lots of rules to disable one or more directions...
      //  1) Small increments are ignored
      //  2) Keep within horizontal limits
      //  3) Keep within vertical limits
      if( GetDirectionLimit() == PAN_UPDOWN || abs(speed.cx) < 5 ) speed.cx = 0;
      else if( GetDirectionLimit() == PAN_LEFTRIGHT || abs(speed.cy) < 5 ) speed.cy = 0;
      if( horz.nPos == horz.nMin && speed.cx > 0 ) speed.cx = 0;
      else if( horz.nPos == horz.nMax && speed.cx < 0 ) speed.cx = 0;
      if( vert.nPos == vert.nMin && speed.cy > 0  )  speed.cy = 0;
      else if( vert.nPos == vert.nMax && speed.cy < 0  ) speed.cy = 0;

      // Return coordinate placement...
      static int dirs[16] =
      {
         /* 00 */ HTNOWHERE,
         /* 01 */ HTRIGHT,
         /* 02 */ HTLEFT,
         /* 03 */ HTERROR,
         /* 04 */ HTBOTTOM,
         /* 05 */ HTBOTTOMRIGHT,
         /* 06 */ HTBOTTOMLEFT,
         /* 07 */ HTERROR,
         /* 08 */ HTTOP,
         /* 09 */ HTTOPRIGHT,
         /* 10 */ HTTOPLEFT,
         /* 11 */ HTERROR,
         /* 12 */ HTERROR,
         /* 13 */ HTERROR,
         /* 14 */ HTERROR,
         /* 15 */ HTERROR,
      };
      int i = 0;
      if( speed.cx != 0 ) i |= speed.cx < 0 ? 1 : 2;
      if( speed.cy != 0 ) i |= speed.cy < 0 ? 4 : 8;
      return dirs[i];
   }
   void OnMove(POINT pt)
   {
      SIZE size = { 0 };
      OnCalculate(pt, size);
      if( size.cx != 0 ) {
         int pos = GetScrollWindow().GetScrollPos(SB_HORZ) - size.cx;
         if( (m_dwStyle & ITS_SETSCROLLINFO) != 0 ) GetScrollWindow().SetScrollPos(SB_HORZ, pos, FALSE);
         GetScrollWindow().SendMessage(WM_HSCROLL, MAKEWPARAM(SB_THUMBPOSITION, pos), NULL);
      }
      if( size.cy != 0 ) {
         int pos = GetScrollWindow().GetScrollPos(SB_VERT) - size.cy;
         if( (m_dwStyle & ITS_SETSCROLLINFO) != 0 ) GetScrollWindow().SetScrollPos(SB_VERT, pos, FALSE);
         GetScrollWindow().SendMessage(WM_VSCROLL, MAKEWPARAM(SB_THUMBPOSITION, pos), NULL);
      }
   }
   void OnScroll(POINT pt)
   {
      OnMove(pt);
   }
   void OnZoom(POINT /*pt*/)
   {
   }
   void OnDataZoom(POINT /*pt*/)
   {
   }
   DWORD OnGetScrollFlags()
   {
      return GetScrollWindow().GetStyle();
   }
};


#endif // !defined(AFX_INTELLIMOUSE_H__20040813_7AA6_5676_CAA3_0080AD509054__INCLUDED_)
