// IntelliTestView.h : interface of the CView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTELLITESTVIEW_H__57597699_95F1_41CC_A739_E8B96302B2BD__INCLUDED_)
#define AFX_INTELLITESTVIEW_H__57597699_95F1_41CC_A739_E8B96302B2BD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Picture.h"
#include "IntelliMouse.h"


class CView : 
   public CWindowImpl<CView>
{
public:
   DECLARE_WND_CLASS(NULL)

   CPicture m_Image;
   CIntelliMouse m_Pan;
   SIZE m_sizeImage;

   BOOL PreTranslateMessage(MSG* pMsg)
   {
      pMsg;
      return FALSE;
   }

   BEGIN_MSG_MAP(CView)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_SIZE, OnSize)
      MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
      MESSAGE_HANDLER(WM_PAINT, OnPaint)
      MESSAGE_HANDLER(WM_VSCROLL, OnScroll)
      MESSAGE_HANDLER(WM_HSCROLL, OnScroll)
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      ModifyStyle(0, WS_VSCROLL | WS_HSCROLL);

      m_Pan.Install(m_hWnd);

      m_Image.Load(IDR_IMAGE);

      CClientDC dc = m_hWnd;
      m_sizeImage = m_Image.GetImageSize(dc);

      return 0;
   }
   LRESULT OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      RECT rcClient = { 0 };
      GetClientRect(&rcClient);
      SetScrollRange(SB_HORZ, 0, m_sizeImage.cx - (rcClient.right - rcClient.left), FALSE);
      SetScrollRange(SB_VERT, 0, m_sizeImage.cy - (rcClient.bottom - rcClient.top), FALSE);
      return 0;
   }
   LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      return 1;
   }
   LRESULT OnPaint(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      CPaintDC dc = m_hWnd;
      RECT rc = { 0, 0, m_sizeImage.cx, m_sizeImage.cy };
      ::OffsetRect(&rc, -GetScrollPos(SB_HORZ), -GetScrollPos(SB_VERT));
      m_Image.Render(dc, rc);
      return 0;
   }
   LRESULT OnScroll(UINT uMsg, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      int sb = uMsg == WM_HSCROLL ? SB_HORZ : SB_VERT;
      SCROLLINFO si = { sizeof(SCROLLINFO), SIF_POS | SIF_RANGE };
      GetScrollInfo(sb, &si);
      int nPos = si.nPos;
      switch( LOWORD(wParam) ) {
      case SB_PAGEUP:
         nPos -= 40;
         break;
      case SB_PAGEDOWN:
         nPos += 40;
         break;
      case SB_THUMBTRACK:      
      case SB_THUMBPOSITION:
         nPos = (int) (short) HIWORD(wParam);
         break;
      }
      if( nPos < si.nMin ) nPos = si.nMin;
      if( nPos > si.nMax ) nPos = si.nMax;
      if( nPos == si.nPos ) return 0;
      /*
      ScrollWindowEx(uMsg == WM_HSCROLL ? si.nPos - nPos : 0,  
         uMsg == WM_VSCROLL  ? si.nPos - nPos : 0, 
         NULL, NULL, NULL, NULL, SW_INVALIDATE); 
       */
      SetScrollPos(sb, nPos, TRUE);
      Invalidate();
      return 0;
   }
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTELLITESTVIEW_H__57597699_95F1_41CC_A739_E8B96302B2BD__INCLUDED_)
