#if !defined(AFX_PICTURE_H__20040814_C6CC_8A04_E7F8_0080AD509054__INCLUDED_)
#define AFX_PICTURE_H__20040814_C6CC_8A04_E7F8_0080AD509054__INCLUDED_

#pragma once

/////////////////////////////////////////////////////////////////////////////
// Picture.h - An IPicture wrapper
//
// Written by Bjarke Viksoe (bjarke@viksoe.dk)
// Based on various internet sources.
// Copyright (c) 2004 Bjarke Viksoe.
//
// This code may be used in compiled form in any way you desire. This
// source file may be redistributed by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to you or your
// computer whatsoever. It's free, so don't hassle me about it.
//
// Beware of bugs.
//

#define HIMETRIC_INCH   2540    // HIMETRIC units per inch 


class CPicture
{
public:
   IPicture* m_pIPicture;

   CPicture() : m_pIPicture(NULL)
   {
   }
   ~CPicture()
   {
      Release();
   }

   BOOL Load(UINT nRes)
   {
#if (_ATL_VER >= 0x0700)
      HINSTANCE hInst = ATL::_AtlBaseModule.GetResourceInstance();
#else
      HINSTANCE hInst = _Module.GetResourceInstance();
#endif
      // Load resource from resource file
      HRSRC hRsrc = ::FindResource(hInst, MAKEINTRESOURCE(nRes), _T("IMAGE"));
      if( hRsrc == NULL ) return FALSE;
      DWORD dwSize = ::SizeofResource(hInst, hRsrc);
      HGLOBAL hResData = ::LoadResource(hInst, hRsrc);
      if( hResData == NULL ) return FALSE;
      // Lock it down
      LPVOID pSrc = ::LockResource(hResData);
      if( pSrc == NULL) {
         ::FreeResource(hResData);
         return FALSE;
      }

      // Allocate memory for stream
      HGLOBAL hGlobal = ::GlobalAlloc(GMEM_MOVEABLE | GMEM_NODISCARD, dwSize);
      if ( hGlobal == NULL ) {
         ::FreeResource(hResData);
         return FALSE;
      }
      LPVOID pDest =  ::GlobalLock(hGlobal);
      if( pDest == NULL ) {
         ::GlobalFree(hGlobal);
         ::FreeResource(hResData);
         return FALSE;
      }
      ::CopyMemory(pDest, pSrc, dwSize);
      ::FreeResource(hResData);
      ::GlobalUnlock(hGlobal);

      // Create the image from the stream
      IStream* pStream = NULL;
      if( FAILED(::CreateStreamOnHGlobal(hGlobal, TRUE, &pStream)) ) {
         ::GlobalFree(hGlobal);
         return FALSE;
      }
      BOOL bRes = Load(pStream);
      pStream->Release();
      return bRes;
   }
   BOOL Load(LPCTSTR pstrFilename, COLORREF clrTransparent = RGB(255,0,255))
   {
      Release();
      USES_CONVERSION;
      return SUCCEEDED( ::OleLoadPicturePath(T2OLE(pstrFilename), NULL, 0, (OLE_COLOR) clrTransparent, IID_IPicture, (LPVOID*) &m_pIPicture) );
   }
   BOOL Load(IStream* pstm)
   {
      Release();
      return SUCCEEDED( ::OleLoadPicture(pstm, 0, FALSE, IID_IPicture, (LPVOID*) &m_pIPicture) );
   }
   BOOL Load(HBITMAP hBitmap, HPALETTE hPalette = NULL, BOOL bTransferOwnership = FALSE)
   {
      Release();
      PICTDESC pdesc = { 0 };
      pdesc.cbSizeofstruct = sizeof(pdesc);
      pdesc.picType = PICTYPE_BITMAP;
      pdesc.bmp.hbitmap = hBitmap;
      pdesc.bmp.hpal = hPalette;
      return SUCCEEDED( ::OleCreatePictureIndirect(&pdesc, IID_IPicture, bTransferOwnership, (LPVOID*) &m_pIPicture) );
   }
   BOOL Load(HICON hIcon, BOOL bTransferOwnership = FALSE)
   {
      Release();
      PICTDESC pdesc = { 0 };
      pdesc.cbSizeofstruct = sizeof(pdesc);
      pdesc.picType = PICTYPE_ICON;
      pdesc.icon.hicon = hIcon;
      return SUCCEEDED( ::OleCreatePictureIndirect(&pdesc, IID_IPicture, bTransferOwnership, (LPVOID*) &m_pIPicture) );
   }
   void Release()
   {
      if( m_pIPicture == NULL ) return;
      m_pIPicture->Release();
      m_pIPicture = NULL;
   }
   operator IPicture*()
   {
      return m_pIPicture;
   }

   BOOL Render(HDC hDC, RECT rc, LPCRECT prcMFBounds = NULL) const
   {
      ATLASSERT(m_pIPicture);

      OLE_XSIZE_HIMETRIC hmWidth;
      OLE_XSIZE_HIMETRIC hmHeight;
      GetHIMETRICSize(hmWidth, hmHeight);

      m_pIPicture->Render(hDC, 
         rc.left, rc.top, 
         rc.right - rc.left, rc.bottom - rc.top,
         0, hmHeight, hmWidth, -hmHeight, 
         prcMFBounds);

      return TRUE;
   }
   SIZE GetImageSize(HDC hDC) const
   {
      ATLASSERT(m_pIPicture);
      SIZE sz = { 0 };
      LONG hmWidth = 0;
      LONG hmHeight = 0;
      m_pIPicture->get_Width(&hmWidth);
      m_pIPicture->get_Height(&hmHeight);
      sz.cx = hmWidth;
      sz.cy = hmHeight;
      if( hDC == NULL ) hDC = ::GetWindowDC(NULL);
      SetHIMETRICtoDP(hDC, sz);
      return sz;
   }
   short GetType() const
   {
      ATLASSERT(m_pIPicture);
      short iPicType = (short) PICTYPE_UNINITIALIZED;
      m_pIPicture->get_Type(&iPicType);
      return iPicType;
   }
   void GetHIMETRICSize(OLE_XSIZE_HIMETRIC& cx, OLE_YSIZE_HIMETRIC& cy) const 
   {
      ATLASSERT(m_pIPicture);
      cx = cy = 0;
      m_pIPicture->get_Width(&cx);
      m_pIPicture->get_Height(&cy);
   } 
   void SetHIMETRICtoDP(HDC hDC, SIZE& sz) const
   {
      int nMapMode = ::GetMapMode(hDC);
      if( nMapMode < MM_ISOTROPIC && nMapMode != MM_TEXT) {
         // When using a constrained map mode, map against physical inch
         ::SetMapMode(hDC, MM_HIMETRIC);
         POINT pt;
         pt.x = sz.cx;
         pt.y = sz.cy;
         ::LPtoDP(hDC,&pt,1);
         sz.cx = pt.x;
         sz.cy = pt.y;
         ::SetMapMode(hDC, nMapMode);
      }
      else {
         // Map against logical inch for non-constrained mapping modes
         int cxPerInch = ::GetDeviceCaps(hDC, LOGPIXELSX);
         int cyPerInch = ::GetDeviceCaps(hDC, LOGPIXELSY);
         sz.cx = MulDiv(sz.cx, cxPerInch, HIMETRIC_INCH);
         sz.cy = MulDiv(sz.cy, cyPerInch, HIMETRIC_INCH);
      }
      POINT pt = { sz.cx, sz.cy };
      ::DPtoLP(hDC, &pt, 1);
      sz.cx = pt.x;
      sz.cy = pt.y;
   }
};


#endif // !defined(AFX_PICTURE_H__20040814_C6CC_8A04_E7F8_0080AD509054__INCLUDED_)
