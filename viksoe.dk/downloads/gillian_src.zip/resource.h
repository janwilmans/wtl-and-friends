//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Gillian.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDI_PANCENTER                   201
#define IDC_PAN_S                       202
#define IDC_PAN_N                       203
#define IDC_PAN_E                       204
#define IDR_IMAGE                       204
#define IDC_PAN_W                       205
#define IDC_PAN_X                       206
#define IDC_PAN_NW                      207
#define IDC_PAN_NE                      208
#define IDC_PAN_SE                      209
#define IDC_PAN_SW                      210

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
