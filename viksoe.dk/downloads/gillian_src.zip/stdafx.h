// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__DEA3AD19_F378_4B16_A09B_C0DFFF00FFFA__INCLUDED_)
#define AFX_STDAFX_H__DEA3AD19_F378_4B16_A09B_C0DFFF00FFFA__INCLUDED_

// Change these values to use different versions
#define WINVER          0x0400
#define _WIN32_WINNT    0x0400
#define _WIN32_IE       0x0400
#define _RICHEDIT_VER   0x0100
#define _CRT_SECURE_NO_WARNINGS

#include <atlbase.h>
#include <atlapp.h>

extern CAppModule _Module;

#include <atlwin.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__DEA3AD19_F378_4B16_A09B_C0DFFF00FFFA__INCLUDED_)
