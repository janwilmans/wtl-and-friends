//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PropertyControlTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDS_TRUE                        129
#define IDS_FALSE                       130
#define IDB_PROPERTYTREE                201
#define IDC_LIST1                       1000
#define IDC_TREE1                       1002
#define IDC_LISTVIEW1                   1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
