//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FadeButtonTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDB_CANCEL_1                    201
#define IDB_CANCEL_2                    202
#define IDD_DIALOG1                     202
#define IDB_BACK_1                      203
#define IDD_DIALOG2                     203
#define IDB_BACK_2                      204
#define IDD_DIALOG3                     204
#define IDB_FORWARD_1                   205
#define IDB_FORWARD_2                   206
#define IDB_ABOUT_1                     207
#define IDB_ABOUT_2                     208
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_TAB                         1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
