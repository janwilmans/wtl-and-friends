// FadeButtonTest.h
